## ----options, cache=FALSE, include=FALSE, results='hide', message=FALSE, warning=FALSE----

knitr::opts_chunk$set(fig.align="center", 
                      cache=FALSE,
                      error=FALSE,
                      fig.width=6,fig.height=6,
                      autodep=TRUE,
                      out.width="600px", 
                      out.height="600px",
                      message=FALSE,
                      warning=FALSE,
                      results="hide", 
                      echo=TRUE, 
                      eval=TRUE)

options(getClass.msg=FALSE)

## ----without_scrambles_without_conditions, results='markdown'------------
library(MPRAnalyze)
# Produce example data: lognormal distributed DNA and poisson distributed RNA
vecSampleEffect <- rep(rnorm(n = 25, mean = 1, sd = 0.1), 4) # Could be barcode effects
vecSampleEffect[vecSampleEffect < 0.2] <- 0.2 # Threshold
vecMuDNA <- sample(x=100, size=20)
matDNACounts <- do.call(rbind, lapply(vecMuDNA, function(mu) {
    round(rlnorm(n=100, meanlog = log(mu), sdlog = 1)*vecSampleEffect)
}))
matDNACounts[matDNACounts <= 1] <- 1
rownames(matDNACounts) <- c(
    paste0("Seq_", 1:20)
)
colnames(matDNACounts) <- paste0("S", 1:100)
vecExprRates <- seq(0.5,2, length.out = 20)
matCondEffect <- matrix(1, nrow=20, ncol=100)
matRNACounts <- do.call(rbind, lapply(1:20, function(i) {
    sapply(matDNACounts[i,]*matCondEffect[i,], function(x) 
        round(rpois(n=1, lambda = x*vecExprRates[i])) )
}))
rownames(matRNACounts) <- rownames(matDNACounts)
colnames(matRNACounts) <- colnames(matDNACounts)
dfAnnotation <- data.frame(
    sample=rownames(matRNACounts),
    barcode=rep(paste0("BC",1:25),4),
    stringsAsFactors = FALSE
)
# Run MPRAnalyze
objMPRA <- runMPRAnalyze(
  matRNACounts=matRNACounts, 
  matDNACounts=matDNACounts, 
  dfAnnotation=dfAnnotation,
  vecCtrlIDs=NULL,
  vecModelFacRNAFull=c("1"),
  vecModelFacRNAFullCtrl=NULL,
  vecModelFacRNARed=NULL,
  vecModelFacRNARedCtrl=NULL,
  vecModelFacDNA=c("barcode"),
  strModel="gammaDNApoisRNA",#"pointlnDNAnbRNA"
  boolPreFitCtrlDNA=FALSE,
  scaNProc=1, 
  boolVerbose=TRUE )
lsExprModels <- getExprModelFull(obj=objMPRA)
print(data.frame(inferred=lsExprModels$baseline,
                 simulated=vecExprRates))

## ----without_scrambles_with_conditions, results='markdown'---------------
# Produce example data: lognormal distributed DNA and poisson distributed RNA
vecSampleEffect <- rep(rnorm(n = 25, mean = 1, sd = 0.1), 4) # Could be barcode effects
vecSampleEffect[vecSampleEffect < 0.2] <- 0.2 # Threshold
vecMuDNA <- sample(x=100, size=20)
matDNACounts <- do.call(rbind, lapply(vecMuDNA, function(mu) {
    round(rlnorm(n=100, meanlog = log(mu), sdlog = 1)*vecSampleEffect)
}))
matDNACounts[matDNACounts <= 1] <- 1
rownames(matDNACounts) <- c(
    paste0("Seq_", 1:20)
)
colnames(matDNACounts) <- paste0("S", 1:100)
vecExprRates <- seq(0.5,2, length.out = 20)
matCondEffect <- matrix(1, nrow=20, ncol=100)
vecCondEffect <- c(rep(1,50), rep(2,50))
vecidxAfftectedEnhancers <- c(1,2,5,10)
for(i in vecidxAfftectedEnhancers) {
    matCondEffect[i,] <- vecCondEffect
}
matRNACounts <- do.call(rbind, lapply(1:20, function(i) {
    sapply(matDNACounts[i,]*matCondEffect[i,], function(x) 
        round(rpois(n=1, lambda = x*vecExprRates[i])) )
}))
rownames(matRNACounts) <- rownames(matDNACounts)
colnames(matRNACounts) <- colnames(matDNACounts)
dfAnnotation <- data.frame(
    sample=rownames(matRNACounts),
    time=c(rep("start", 50),rep("end", 50)),
    barcode=rep(paste0("BC",1:25),4),
    stringsAsFactors = FALSE
)
# Run MPRAnalyze
objMPRA <- runMPRAnalyze(
  matRNACounts=matRNACounts, 
  matDNACounts=matDNACounts, 
  dfAnnotation=dfAnnotation,
  vecCtrlIDs=NULL,
  vecModelFacRNAFull=c("1","time"),
  vecModelFacRNAFullCtrl=NULL,
  vecModelFacRNARed=c("1"),
  vecModelFacRNARedCtrl=NULL,
  vecModelFacDNA=c("barcode", "time"),
  strModel="gammaDNApoisRNA",#"pointlnDNAnbRNA"
  boolPreFitCtrlDNA=FALSE,
  scaNProc=1, 
  boolVerbose=TRUE )
objMPRA$dfMPRAnalyzeResults[order(objMPRA$dfMPRAnalyzeResults$p),]

## ----with_scrambles_without_conditions, results='markdown'---------------
# Produce example data: lognormal distributed DNA and poisson distributed RNA
vecSampleEffect <- rep(rnorm(n = 25, mean = 1, sd = 0.1), 4) # Could be barcode effects
vecSampleEffect[vecSampleEffect < 0.2] <- 0.2 # Threshold
vecMuDNA <- sample(x=100, size=20)
matDNACounts <- do.call(rbind, lapply(vecMuDNA, function(mu) {
    round(rlnorm(n=100, meanlog = log(mu), sdlog = 1)*vecSampleEffect)
}))
matDNACounts[matDNACounts <= 1] <- 1
rownames(matDNACounts) <- c(
    paste0("Seq_", 1:10), paste0("Ctrl_", 1:10)
)
colnames(matDNACounts) <- paste0("S", 1:100)
vecExprRates <- c(rep(1.5, 5), rep(0.5, 15))
matCondEffect <- matrix(1, nrow=20, ncol=100)
matRNACounts <- do.call(rbind, lapply(1:20, function(i) {
    sapply(matDNACounts[i,]*matCondEffect[i,], function(x) 
        round(rpois(n=1, lambda = x*vecExprRates[i])) )
}))
rownames(matRNACounts) <- rownames(matDNACounts)
colnames(matRNACounts) <- colnames(matDNACounts)
dfAnnotation <- data.frame(
    sample=rownames(matRNACounts),
    barcode=rep(paste0("BC",1:25),4),
    stringsAsFactors = FALSE
)
# Run MPRAnalyze
objMPRA <- runMPRAnalyze(
  matRNACounts=matRNACounts, 
  matDNACounts=matDNACounts, 
  dfAnnotation=dfAnnotation,
  vecCtrlIDs=paste0("Ctrl_", 1:10),
  vecModelFacRNAFull=c("1"),
  vecModelFacRNAFullCtrl=c("1"),
  vecModelFacRNARed=c("1"),
  vecModelFacRNARedCtrl=NULL,
  vecModelFacDNA=c("barcode"),
  strModel="gammaDNApoisRNA",#"pointlnDNAnbRNA"
  boolPreFitCtrlDNA=TRUE,
  scaNProc=1, 
  boolVerbose=TRUE )
objMPRA$dfMPRAnalyzeResults[order(objMPRA$dfMPRAnalyzeResults$padj),]

## ----with_scrambles_with_conditions, results='markdown'------------------
# Produce example data: lognormal distributed DNA and poisson distributed RNA
vecSampleEffect <- rep(rnorm(n = 25, mean = 1, sd = 0.1), 4) # Could be barcode effects
vecSampleEffect[vecSampleEffect < 0.2] <- 0.2 # Threshold
vecMuDNA <- sample(x=100, size=20)
matDNACounts <- do.call(rbind, lapply(vecMuDNA, function(mu) {
    round(rlnorm(n=100, meanlog = log(mu), sdlog = 1)*vecSampleEffect)
}))
matDNACounts[matDNACounts <= 1] <- 1
rownames(matDNACounts) <- c(
    paste0("Seq_", 1:10), paste0("Ctrl_", 1:10)
)
colnames(matDNACounts) <- paste0("S", 1:100)
vecExprRates <- c(rep(0.5,10), rep(1.5,10))
matCondEffect <- matrix(1, nrow=20, ncol=100)
vecCondEffect <- c(rep(1,50), rep(2,50))
vecidxAfftectedEnhancers <- c(1,2,5,10)
for(i in vecidxAfftectedEnhancers) {
    matCondEffect[i,] <- vecCondEffect
}
matRNACounts <- do.call(rbind, lapply(1:20, function(i) {
    sapply(matDNACounts[i,]*matCondEffect[i,], function(x) 
        round(rpois(n=1, lambda = x*vecExprRates[i])) )
}))
rownames(matRNACounts) <- rownames(matDNACounts)
colnames(matRNACounts) <- colnames(matDNACounts)
dfAnnotation <- data.frame(
    sample=rownames(matRNACounts),
    time=c(rep("start", 50),rep("end", 50)),
    barcode=rep(paste0("BC",1:25),4),
    stringsAsFactors = FALSE
)
# Run MPRAnalyze
objMPRA <- runMPRAnalyze(
  matRNACounts=matRNACounts, 
  matDNACounts=matDNACounts, 
  dfAnnotation=dfAnnotation,
  vecCtrlIDs=paste0("Ctrl_", 1:10),
  vecModelFacRNAFull=c("1","time"),
  vecModelFacRNAFullCtrl=c("1","time"),
  vecModelFacRNARed=c("1","time"),
  vecModelFacRNARedCtrl=c("1"),
  vecModelFacDNA=c("barcode", "time"),
  strModel="gammaDNApoisRNA",#"pointlnDNAnbRNA"
  boolPreFitCtrlDNA=TRUE,
  scaNProc=1, 
  boolVerbose=TRUE )
objMPRA$dfMPRAnalyzeResults[order(objMPRA$dfMPRAnalyzeResults$padj),]

## ----session-------------------------------------------------------------
sessionInfo()

